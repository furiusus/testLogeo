CREATE VIEW GV_$OBSOLETE_PARAMETER AS select "INST_ID","NAME","ISSPECIFIED" from gv$obsolete_parameter
/
