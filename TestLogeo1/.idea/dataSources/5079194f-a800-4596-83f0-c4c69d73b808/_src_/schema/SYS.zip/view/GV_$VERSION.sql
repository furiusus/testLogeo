CREATE VIEW GV_$VERSION AS select "INST_ID","BANNER" from gv$version
/
