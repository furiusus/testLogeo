CREATE VIEW V_$PROCESS_GROUP AS select "INDX","NAME","PID" from v$process_group
/
