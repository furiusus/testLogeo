CREATE VIEW V_$SGAINFO AS select "NAME","BYTES","RESIZEABLE" from v$sgainfo
/
