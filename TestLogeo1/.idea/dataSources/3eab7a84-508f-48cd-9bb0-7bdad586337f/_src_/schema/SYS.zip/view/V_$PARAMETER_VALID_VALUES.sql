CREATE VIEW V_$PARAMETER_VALID_VALUES AS select "NUM","NAME","ORDINAL","VALUE","ISDEFAULT" from v$parameter_valid_values
/
