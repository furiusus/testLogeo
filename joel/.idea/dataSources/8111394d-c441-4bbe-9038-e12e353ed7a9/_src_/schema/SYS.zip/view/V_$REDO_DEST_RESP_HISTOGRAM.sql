CREATE VIEW V_$REDO_DEST_RESP_HISTOGRAM AS select "DEST_ID","TIME","DURATION","FREQUENCY" from v$redo_dest_resp_histogram
/
