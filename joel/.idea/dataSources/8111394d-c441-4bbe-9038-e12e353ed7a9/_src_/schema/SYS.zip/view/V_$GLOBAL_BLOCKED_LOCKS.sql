CREATE VIEW V_$GLOBAL_BLOCKED_LOCKS AS select "ADDR","KADDR","SID","TYPE","ID1","ID2","LMODE","REQUEST","CTIME" from v$global_blocked_locks
/
