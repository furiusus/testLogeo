CREATE VIEW GV_$ACCESS AS select "INST_ID","SID","OWNER","OBJECT","TYPE" from gv$access
/
