create view GV_$DB_PIPES as
select "INST_ID","OWNERID","NAME","TYPE","PIPE_SIZE" from gv$db_pipes
