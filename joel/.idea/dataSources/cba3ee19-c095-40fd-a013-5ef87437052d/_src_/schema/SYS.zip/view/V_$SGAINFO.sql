create view V_$SGAINFO as
select "NAME","BYTES","RESIZEABLE" from v$sgainfo
