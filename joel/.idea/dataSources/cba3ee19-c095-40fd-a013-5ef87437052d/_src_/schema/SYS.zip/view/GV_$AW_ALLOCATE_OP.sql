create view GV_$AW_ALLOCATE_OP as
select "INST_ID","NAME","LONGNAME" from gv$aw_allocate_op
