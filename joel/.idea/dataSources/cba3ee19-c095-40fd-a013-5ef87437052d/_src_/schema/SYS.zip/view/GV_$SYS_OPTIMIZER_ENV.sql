create view GV_$SYS_OPTIMIZER_ENV as
select "INST_ID","ID","NAME","SQL_FEATURE","ISDEFAULT","VALUE","DEFAULT_VALUE" from gv$sys_optimizer_env
