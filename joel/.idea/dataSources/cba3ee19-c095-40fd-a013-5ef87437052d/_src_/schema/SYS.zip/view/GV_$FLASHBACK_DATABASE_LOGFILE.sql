create view GV_$FLASHBACK_DATABASE_LOGFILE as
select "INST_ID","NAME","LOG#","THREAD#","SEQUENCE#","BYTES","FIRST_CHANGE#","FIRST_TIME","TYPE" from gv$flashback_database_logfile
