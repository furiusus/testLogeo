create view V_$DETACHED_SESSION as
select "INDX","PG_NAME","SID","SERIAL#","PID" from v$detached_session
