create view GV_$SGA as
select "INST_ID","NAME","VALUE" from gv$sga
