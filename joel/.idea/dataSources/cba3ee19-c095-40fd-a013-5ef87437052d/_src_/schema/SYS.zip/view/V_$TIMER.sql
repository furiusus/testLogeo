create view V_$TIMER as
select "HSECS" from v$timer
