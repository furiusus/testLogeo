create view V_$SESSION_WAIT_CLASS as
select "SID","SERIAL#","WAIT_CLASS_ID","WAIT_CLASS#","WAIT_CLASS","TOTAL_WAITS","TIME_WAITED" from v$session_wait_class
