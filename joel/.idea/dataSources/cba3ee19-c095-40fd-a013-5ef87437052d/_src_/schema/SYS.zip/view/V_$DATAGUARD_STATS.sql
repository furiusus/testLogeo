create view V_$DATAGUARD_STATS as
select "NAME","VALUE","UNIT","TIME_COMPUTED","DATUM_TIME" from v$dataguard_stats
