create view V_$HS_PARAMETER as
select "HS_SESSION_ID","PARAMETER","VALUE","SOURCE","ENV" from v$hs_parameter
