create view V_$SQLTEXT as
select "ADDRESS","HASH_VALUE","SQL_ID","COMMAND_TYPE","PIECE","SQL_TEXT" from v$sqltext
