create view V_$SESSION_CURSOR_CACHE as
select "MAXIMUM","COUNT","OPENS","HITS","HIT_RATIO" from v$session_cursor_cache
