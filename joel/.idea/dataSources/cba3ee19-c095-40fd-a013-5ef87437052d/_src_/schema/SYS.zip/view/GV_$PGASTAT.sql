create view GV_$PGASTAT as
select "INST_ID","NAME","VALUE","UNIT" from gv$pgastat
