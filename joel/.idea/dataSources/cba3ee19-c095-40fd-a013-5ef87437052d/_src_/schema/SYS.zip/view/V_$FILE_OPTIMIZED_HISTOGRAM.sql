create view V_$FILE_OPTIMIZED_HISTOGRAM as
select "FILE#","SINGLEBLKRDTIM_MICRO","SINGLEBLKRDS" from v$file_optimized_histogram
