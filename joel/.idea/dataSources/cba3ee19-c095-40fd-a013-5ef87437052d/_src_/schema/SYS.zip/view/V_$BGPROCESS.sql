create view V_$BGPROCESS as
select "PADDR","PSERIAL#","NAME","DESCRIPTION","ERROR" from v$bgprocess
