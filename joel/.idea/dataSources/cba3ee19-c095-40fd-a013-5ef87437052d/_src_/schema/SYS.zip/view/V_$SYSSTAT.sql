create view V_$SYSSTAT as
select "STATISTIC#","NAME","CLASS","VALUE","STAT_ID" from v$sysstat
