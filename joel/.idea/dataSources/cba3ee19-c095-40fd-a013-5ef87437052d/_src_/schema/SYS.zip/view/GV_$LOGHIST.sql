create view GV_$LOGHIST as
select "INST_ID","THREAD#","SEQUENCE#","FIRST_CHANGE#","FIRST_TIME","SWITCH_CHANGE#" from gv$loghist
