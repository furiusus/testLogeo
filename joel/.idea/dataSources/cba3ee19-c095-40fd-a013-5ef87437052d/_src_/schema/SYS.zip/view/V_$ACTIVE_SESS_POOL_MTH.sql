create view V_$ACTIVE_SESS_POOL_MTH as
select "NAME" from v$active_sess_pool_mth
