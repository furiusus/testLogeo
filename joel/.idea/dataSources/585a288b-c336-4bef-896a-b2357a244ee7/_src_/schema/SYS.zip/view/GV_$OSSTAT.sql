create view GV_$OSSTAT as
select "INST_ID","STAT_NAME","VALUE","OSSTAT_ID","COMMENTS","CUMULATIVE" from gv$osstat
