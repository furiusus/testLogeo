create view V_$REDO_DEST_RESP_HISTOGRAM as
select "DEST_ID","TIME","DURATION","FREQUENCY" from v$redo_dest_resp_histogram
