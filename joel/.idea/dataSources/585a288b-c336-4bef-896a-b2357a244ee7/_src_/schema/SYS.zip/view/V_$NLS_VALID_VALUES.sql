create view V_$NLS_VALID_VALUES as
select "PARAMETER","VALUE","ISDEPRECATED" from v$nls_valid_values
