create view GV_$SYSSTAT as
select "INST_ID","STATISTIC#","NAME","CLASS","VALUE","STAT_ID" from gv$sysstat
