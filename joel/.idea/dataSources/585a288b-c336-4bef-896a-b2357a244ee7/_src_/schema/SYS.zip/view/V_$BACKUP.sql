create view V_$BACKUP as
select "FILE#","STATUS","CHANGE#","TIME" from v$backup
