create view V_$EXECUTION as
select "PID","DEPTH","FUNCTION","TYPE","NVALS","VAL1","VAL2","SEQH","SEQL" from v$execution
