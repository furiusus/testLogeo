create view V_$DLM_MISC as
select "STATISTIC#","NAME","VALUE" from v$dlm_misc
