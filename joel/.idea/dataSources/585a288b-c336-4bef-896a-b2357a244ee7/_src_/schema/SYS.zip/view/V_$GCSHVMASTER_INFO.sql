create view V_$GCSHVMASTER_INFO as
select "HV_ID","CURRENT_MASTER","PREVIOUS_MASTER","REMASTER_CNT" from v$gcshvmaster_info
