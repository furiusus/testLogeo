create view GV_$DLM_CONVERT_REMOTE as
select "INST_ID","CONVERT_TYPE","AVERAGE_CONVERT_TIME","CONVERT_COUNT" from gv$dlm_convert_remote
