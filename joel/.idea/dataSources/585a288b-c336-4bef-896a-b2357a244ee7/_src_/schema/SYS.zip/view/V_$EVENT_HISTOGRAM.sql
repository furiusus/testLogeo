create view V_$EVENT_HISTOGRAM as
select "EVENT#","EVENT","WAIT_TIME_MILLI","WAIT_COUNT","LAST_UPDATE_TIME" from v$event_histogram
