create view V_$TYPE_SIZE as
select "COMPONENT","TYPE","DESCRIPTION","TYPE_SIZE" from v$type_size
