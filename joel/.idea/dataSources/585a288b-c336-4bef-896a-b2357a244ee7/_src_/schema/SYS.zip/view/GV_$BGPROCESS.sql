create view GV_$BGPROCESS as
select "INST_ID","PADDR","PSERIAL#","NAME","DESCRIPTION","ERROR" from gv$bgprocess
