create view V_$QUEUE as
select "PADDR","TYPE","QUEUED","WAIT","TOTALQ" from v$queue
